/* beta.h                                   */
/* DF2 filter coefficients                  */
/* exported from MATLAB using fir_dump2c.m  */


#define b_LENGTH 8000

extern float b[];

